function doGet(e) {
  return createRes("success", "GAS API is working");
}

const SITE_URL = "https://lqzayu.github.io/VSCode/";

const ADMIN_USER_ID = "admin";
const RECRUITMENT_DURATION_MINUTES = [15, 30, 45, 60, 120, 180, 240, 300, 360, 420, 480, 540, 600, 660, 720, 780, 840, 900, 960, 1020, 1080, 1140, 1200, 1260, 1320, 1380, 1440];
const ONLINE_TIMEOUT_MS = 90 * 1000;

const LINE_ACCESS_TOKEN = PropertiesService.getScriptProperties().getProperty("LINE_ACCESS_TOKEN") || "";

function doPost(e) {
  try {
    const output = ContentService.createTextOutput();
    output.setMimeType(ContentService.MimeType.JSON);

    const ss = SpreadsheetApp.getActiveSpreadsheet();

    if (!e || !e.postData || !e.postData.contents) {
      output.setContent(JSON.stringify({ status: "success", message: "VERIFIED_OK" }));
      return output;
    }

    const rawData = e.postData.contents;

    const sheetUser = ss.getSheetByName("シート1");
    const sheetRecruit = ss.getSheetByName("募集");
    const sheetChat = ss.getSheetByName("チャット");
    const sheetChatCopy = ss.getSheetByName("chat-copy");
    const sheetOnline = ss.getSheetByName("オンライン状況");
    const sheetHiddenChat = ss.getSheetByName("チャット非表示");
    const sheetBlock = ss.getSheetByName("ブロック");
    const sheetReport = ss.getSheetByName("通報");

    if (rawData.includes("events")) {
      const lineData = JSON.parse(rawData);

      if (lineData.events && lineData.events.length === 0) {
        output.setContent(JSON.stringify({ status: "success", message: "EMPTY_EVENT_OK" }));
        return output;
      }

      if (lineData.events && lineData.events.length > 0) {
        const event = lineData.events[0];
        const lineUserId = event.source ? event.source.userId : "";
        const replyToken = event.replyToken;

        if (event.type === "message" && event.message && event.message.type === "text") {
          const inputText = event.message.text.trim();

          if (sheetUser && sheetUser.getLastRow() > 1) {
            const rows = sheetUser.getDataRange().getValues();
            let matchedUserIndex = -1;
            let matchedUserName = "";

            for (let i = 1; i < rows.length; i++) {
              const cellUserId = rows[i][0] ? rows[i][0].toString().trim().toLowerCase() : "";
              const cellEmail = rows[i][5] ? rows[i][5].toString().trim().toLowerCase() : "";
              const cleanInput = inputText.toLowerCase();

              if (cellUserId === cleanInput || cellEmail === cleanInput) {
                matchedUserIndex = i + 1;
                matchedUserName = rows[i][2] || rows[i][0];
                break;
              }
            }

            if (matchedUserIndex !== -1) {
              sheetUser.getRange(matchedUserIndex, 12).setValue(lineUserId);
              const successMsg = `✅ 【平工マッチング】LINE連携完了\n\n${matchedUserName} さんのアカウントとLINEの連携が成功しました！\n今後はメッセージが届いた際に通知をお届けします。`;
              replyLineMessage(replyToken, successMsg);
            } else {
              const errorMsg = `⚠️ ユーザーが見つかりませんでした。\n\nWebアプリで登録した「ユーザーID」または「メールアドレス」を正しく送信してください。`;
              replyLineMessage(replyToken, errorMsg);
            }
          }
        }
      }

      output.setContent(JSON.stringify({ status: "success", message: "LINE_WEBHOOK_PROCESSED" }));
      return output;
    }

    const data = JSON.parse(rawData);
    const mode = data.mode;

    if (mode === "heartbeat") {
      const userId = String(data.userId || "").trim();
      if (!userId || !userExists(sheetUser, userId)) return createRes("error", "ユーザーが見つかりません");

      const onlineSheet = sheetOnline || getOrCreateSheet(ss, "オンライン状況", ["UserID", "最終アクセス"]);
      touchOnlineUser(onlineSheet, userId);
      return createRes("success", "HEARTBEAT_OK");
    }

    if (mode === "getUserProfile") {
      const identifier = String(data.userId || data.email || "").trim();
      if (!identifier || !sheetUser || sheetUser.getLastRow() <= 1) {
        return createRes("error", "ユーザーが見つかりません");
      }

      const rows = sheetUser.getDataRange().getValues();
      const userRow = findUserRow(rows, identifier);
      if (!userRow) return createRes("error", "ユーザーが見つかりません");

      return createRes("success", {
        userId: cleanCell(userRow[0]),
        email: cleanCell(userRow[5]) || cleanCell(userRow[0]),
        name: cleanCell(userRow[2]),
        profileImage: cleanCell(userRow[4])
      });
    }

    if (mode === "adminGetOverview") {
      if (data.adminId !== ADMIN_USER_ID) return createRes("error", "管理者権限がありません");

      const userRows = sheetUser && sheetUser.getLastRow() > 1 ? sheetUser.getDataRange().getValues() : [];
      let users = [];
      for (let i = 1; i < userRows.length; i++) {
        users.push({
          userId: userRows[i][0],
          name: userRows[i][2] || "未設定",
          email: userRows[i][5] || "",
          isVerified: userRows[i][6] === true
        });
      }

      const recruitRows = sheetRecruit && sheetRecruit.getLastRow() > 1 ? sheetRecruit.getDataRange().getValues() : [];
      let posts = [];
      for (let j = 1; j < recruitRows.length; j++) {
        posts.push({
          rowIndex: j + 1,
          name: recruitRows[j][0],
          grade: recruitRows[j][1],
          dept: recruitRows[j][2],
          content: recruitRows[j][3],
          time: recruitRows[j][4],
          email: recruitRows[j][5],
          tags: recruitRows[j][6] || ""
        });
      }

      const onlineUserIds = getOnlineUserIds(sheetOnline).filter(userId => userId !== ADMIN_USER_ID);

      return createRes("success", {
        users: users,
        posts: posts,
        onlineCount: onlineUserIds.length
      });
    }

    if (mode === "adminDeletePost") {
      if (data.adminId !== ADMIN_USER_ID) return createRes("error", "管理者権限がありません");
      if (!sheetRecruit) return createRes("error", "シートが見つかりません");

      const targetEmail = data.targetEmail;
      const recruitRows = sheetRecruit.getDataRange().getValues();
      for (let k = recruitRows.length - 1; k >= 1; k--) {
        if (recruitRows[k][5] === targetEmail) {
          sheetRecruit.deleteRow(k + 1);
          return createRes("success", "POST_DELETED");
        }
      }
      return createRes("error", "対象の投稿が見つかりませんでした");
    }

    if (mode === "adminBanUser") {
      if (data.adminId !== ADMIN_USER_ID) return createRes("error", "管理者権限がありません");
      if (!sheetUser) return createRes("error", "シートが見つかりません");

      const targetUserId = data.targetUserId;
      const userRows = sheetUser.getDataRange().getValues();
      let targetEmail = "";
      let newStatus = false;

      for (let u = userRows.length - 1; u >= 1; u--) {
        if (userRows[u][0] === targetUserId) {
          targetEmail = userRows[u][5];
          const currentStatus = userRows[u][6] === true;
          newStatus = !currentStatus;

          sheetUser.getRange(u + 1, 7).setValue(newStatus);
          break;
        }
      }

      if (!newStatus && targetEmail && sheetRecruit && sheetRecruit.getLastRow() > 1) {
        const recruitRows = sheetRecruit.getDataRange().getValues();
        for (let r = recruitRows.length - 1; r >= 1; r--) {
          if (recruitRows[r][5] === targetEmail) {
            sheetRecruit.deleteRow(r + 1);
          }
        }
      }

      return createRes("success", newStatus ? "USER_UNBANNED" : "USER_BANNED");
    }

    if (mode === "register") {
      if (!sheetUser) return createRes("error", "シートが存在しません");
      if (!data.userId || !data.email || !data.password) {
        return createRes("error", "必要な項目が入力されていません");
      }

      const rows = sheetUser.getLastRow() > 0 ? sheetUser.getDataRange().getValues() : [];
      let existingRowIndex = -1;
      for (let i = 0; i < rows.length; i++) {
        if (rows[i][0] === data.userId) {
          existingRowIndex = i + 1;
          break;
        }
      }

      if (existingRowIndex !== -1 && rows[existingRowIndex - 1][6] === true) {
        return createRes("error", "このユーザーIDは既に登録されています");
      }

      const code = generateVerificationCode();
      const expiry = new Date().getTime() + (10 * 60 * 1000);

      const rowData = [
        data.userId,
        hashPassword(data.password),
        data.name || "ユーザー",
        data.faceFeatures || "",
        "",
        data.email,
        false,
        code,
        expiry,
        "",
        "",
        ""
      ];

      if (existingRowIndex !== -1) {
        sheetUser.getRange(existingRowIndex, 1, 1, rowData.length).setValues([rowData]);
      } else {
        sheetUser.appendRow(rowData);
      }

      MailApp.sendEmail({
        to: data.email,
        name: "平工マッチング",
        subject: "【平工マッチング】認証コードのご案内",
        body: `平工マッチングにご登録いただきありがとうございます。\n\n以下の認証コードを、登録画面に入力してください。\n\n認証コード: ${code}\n\n（10分間有効です）`
      });

      return createRes("success", "CODE_SENT");
    }

    if (mode === "verifyEmail") {
      const userId = data.userId;
      const code = data.code;

      if (!sheetUser || sheetUser.getLastRow() === 0) return createRes("error", "ユーザーが見つかりません");
      const rows = sheetUser.getDataRange().getValues();

      let userRowIndex = -1;
      for (let i = 0; i < rows.length; i++) {
        if (rows[i][0] === userId) {
          userRowIndex = i + 1;
          break;
        }
      }
      if (userRowIndex === -1) return createRes("error", "ユーザーが見つかりません");

      const row = rows[userRowIndex - 1];

      if (row[6] === true) {
        return createRes("success", "ALREADY_VERIFIED");
      }

      const savedCode = row[7];
      const savedExpiry = row[8];

      if (!savedCode || savedCode.toString() !== code.toString()) {
        return createRes("error", "認証コードが間違っています");
      }
      if (!savedExpiry || new Date().getTime() > savedExpiry) {
        return createRes("error", "認証コードの有効期限が切れています。");
      }

      sheetUser.getRange(userRowIndex, 7).setValue(true);
      sheetUser.getRange(userRowIndex, 8).setValue("");
      sheetUser.getRange(userRowIndex, 9).setValue("");

      return createRes("success", "VERIFIED");
    }

    if (mode === "resendVerificationCode") {
      const userId = data.userId;
      if (!sheetUser || sheetUser.getLastRow() === 0) return createRes("error", "ユーザーが見つかりません");
      const rows = sheetUser.getDataRange().getValues();

      let userRowIndex = -1;
      for (let i = 0; i < rows.length; i++) {
        if (rows[i][0] === userId) {
          userRowIndex = i + 1;
          break;
        }
      }
      if (userRowIndex === -1) return createRes("error", "ユーザーが見つかりません");

      const row = rows[userRowIndex - 1];

      if (row[6] === true) return createRes("success", "ALREADY_VERIFIED");

      const email = row[5];
      const code = generateVerificationCode();
      const expiry = new Date().getTime() + (10 * 60 * 1000);

      sheetUser.getRange(userRowIndex, 8).setValue(code);
      sheetUser.getRange(userRowIndex, 9).setValue(expiry);

      MailApp.sendEmail({
        to: email,
        name: "平工マッチング",
        subject: "【平工マッチング】認証コードの再送",
        body: `認証コードを再送します。\n\n認証コード: ${code}`
      });

      return createRes("success", "CODE_RESENT");
    }

    if (mode === "login") {
      if (!sheetUser || sheetUser.getLastRow() === 0) return createRes("error", "ユーザーが見つかりません");
      const rows = sheetUser.getDataRange().getValues();
      const user = rows.find(row => row[0] === data.email);

      if (!user) {
        return createRes("error", "ユーザーIDが見つかりません。");
      }

      if (user[6] !== true) {
        return createRes("error", "メール認証が完了していません。");
      }

      const dbPassword = user[1] ? user[1].toString().trim() : "";
      const inputPasswordHash = hashPassword(data.password ? data.password.toString().trim() : "");

      if (dbPassword === inputPasswordHash) {
        return createRes("success", {
          userId: user[0],
          email: user[0],
          name: cleanCell(user[2]),
          profileImage: user[4] || ""
        });
      } else {
        return createRes("error", "パスワードが間違っています");
      }
    }

    if (mode === "verify_face_1toN") {
      return createRes("error", "顔認証にはユーザーIDの入力が必要です。");
    }

    if (mode === "verify_face_for_user") {
      if (!sheetUser || sheetUser.getLastRow() === 0) return createRes("error", "登録データがありません");

      const userId = data.userId ? data.userId.toString().trim() : "";
      const currentLandmarks = data.currentFeatures;
      const currentSamples = Array.isArray(data.currentFeaturesSamples) ? data.currentFeaturesSamples : [];
      if (!userId) return createRes("error", "顔認証前にユーザーIDを入力してください。");
      if (!Array.isArray(currentLandmarks)) return createRes("error", "顔情報を取得できませんでした。");
      if (currentSamples.length < 2) return createRes("error", "顔情報を安定して取得できませんでした。もう一度お試しください。");

      const rows = sheetUser.getDataRange().getValues();
      const userRow = rows.find(row => row[0] && row[0].toString().trim() === userId);

      if (!userRow) return createRes("error", "ユーザーIDが見つかりません。");
      if (userRow[6] !== true) return createRes("error", "メール認証が完了していません。");
      if (!userRow[3]) return createRes("error", "このユーザーには顔情報が登録されていません。");

      try {
        const registeredLandmarks = JSON.parse(userRow[3]);
        const scores = currentSamples.map(sample => getFaceDistance(sample, registeredLandmarks));
        scores.push(getFaceDistance(currentLandmarks, registeredLandmarks));
        const validScores = scores.filter(score => score !== null);
        const passingScores = validScores.filter(score => score <= 0.06);
        if (validScores.length < 2 || passingScores.length < 2) {
          return createRes("error", "顔情報が一致しませんでした。明るい場所で正面を向いて、もう一度お試しください。");
        }

        return createRes("success", {
          userId: userRow[0],
          email: userRow[0],
          name: cleanCell(userRow[2]),
          profileImage: userRow[4] || ""
        });
      } catch (e) {
        return createRes("error", "顔情報を確認できませんでした。");
      }
    }

    if (mode === "updateProfile") {
      const email = data.email;
      const name = data.name;
      const profileImage = data.profileImage;
      if (!sheetUser || sheetUser.getLastRow() === 0) return createRes("error", "ユーザーが見つかりません");
      const rows = sheetUser.getDataRange().getValues();

      let userRowIndex = -1;
      for (let i = 0; i < rows.length; i++) {
        if (rows[i][0] === email) {
          userRowIndex = i + 1;
          break;
        }
      }

      if (userRowIndex !== -1) {
        sheetUser.getRange(userRowIndex, 3).setValue(name);
        if (profileImage) {
          sheetUser.getRange(userRowIndex, 5).setValue(profileImage);
        }
        return createRes("success", "PROFILE_UPDATED");
      } else {
        return createRes("error", "対象ユーザーが見つかりません");
      }
    }

    if (mode === "updateFaceFeatures") {
      const email = data.email;
      const faceFeatures = data.faceFeatures;
      if (!sheetUser || sheetUser.getLastRow() === 0) return createRes("error", "ユーザーが見つかりません");
      const rows = sheetUser.getDataRange().getValues();

      let userRowIndex = -1;
      for (let i = 0; i < rows.length; i++) {
        if (rows[i][0] === email) {
          userRowIndex = i + 1;
          break;
        }
      }

      if (userRowIndex !== -1) {
        sheetUser.getRange(userRowIndex, 4).setValue(faceFeatures);
        return createRes("success", "顔認証情報をアップデートしました");
      } else {
        return createRes("error", "対象ユーザーが見つかりません");
      }
    }

    if (mode === "getRecruitments") {
      if (!sheetRecruit || sheetRecruit.getLastRow() <= 1) return createRes("success", []);

      const rows = sheetRecruit.getDataRange().getValues();
      const now = Date.now();
      let list = [];

      for (let i = 1; i < rows.length; i++) {
        const postTime = new Date(rows[i][4]).getTime();

        if (Number.isNaN(postTime)) continue;

        const durationMinutes = normalizeRecruitmentDuration(rows[i][7]);
        const expiresAt = postTime + durationMinutes * 60 * 1000;

        if (now < expiresAt && !isBlockedBetween(sheetBlock, data.email, rows[i][5])) {
          list.push({
            name: rows[i][0],
            grade: rows[i][1],
            dept: rows[i][2],
            content: rows[i][3],
            time: postTime,
            email: rows[i][5],
            tags: rows[i][6] || "",
            durationMinutes: durationMinutes
          });
        }
      }

      return createRes("success", list);
    }

    if (mode === "postRecruitment") {
      if (!sheetRecruit) return createRes("error", "シートが存在しません");

      ensureRecruitmentDurationColumn(sheetRecruit);
      const rows = sheetRecruit.getLastRow() > 0 ? sheetRecruit.getDataRange().getValues() : [];
      let existingRowIndex = -1;
      for (let i = 1; i < rows.length; i++) {
        if (rows[i][5] === data.email) {
          existingRowIndex = i + 1;
          break;
        }
      }
      const durationMinutes = normalizeRecruitmentDuration(data.durationMinutes);
      const rowData = [data.name, data.grade, data.dept, data.content, new Date(), data.email, data.tags || "", durationMinutes];

      if (existingRowIndex !== -1) {
        sheetRecruit.getRange(existingRowIndex, 1, 1, 8).setValues([rowData]);
        return createRes("success", "UPDATED");
      } else {
        sheetRecruit.appendRow(rowData);
        return createRes("success", "CREATED");
      }
    }

    if (mode === "deleteRecruitment") {
      if (!sheetRecruit || sheetRecruit.getLastRow() <= 1) return createRes("success", "NOT_FOUND");
      const rows = sheetRecruit.getDataRange().getValues();
      const myEmail = data.email;
      for (let i = rows.length - 1; i >= 1; i--) {
        if (rows[i][5] === myEmail) {
          sheetRecruit.deleteRow(i + 1);
          return createRes("success", "DELETED");
        }
      }
      return createRes("success", "NOT_FOUND");
    }

    if (mode === "sendMessage") {
      if (!sheetChat) return createRes("error", "チャットシートが存在しません");

      ensureChatColumns(sheetChat);
      if (sheetChatCopy) ensureChatColumns(sheetChatCopy);

      const attachmentInput = Array.isArray(data.attachments) ? data.attachments.slice(0, 8) : [];
      let attachmentUrls = [];

      const lock = LockService.getScriptLock();
      try {
        if (attachmentInput.length > 0) {
          attachmentUrls = saveChatAttachments(attachmentInput, data.from);
        }

        lock.waitLock(5000);

        const now = new Date();
        const messageId = Utilities.getUuid();
        const rowData = [data.from, data.to, data.text || "", now, "unread", messageId, "active", JSON.stringify(attachmentUrls)];

        sheetChat.appendRow(rowData);
        if (sheetChatCopy) sheetChatCopy.appendRow(rowData);
        SpreadsheetApp.flush();

        let senderName = cleanCell(data.from) || "ユーザー";
        if (sheetUser && sheetUser.getLastRow() > 0) {
          const userRows = sheetUser.getDataRange().getValues();
          const senderRow = findUserRow(userRows, data.from);
          senderName = getUserDisplayName(senderRow, senderName);
        }

        let recipientLineId = "";
        if (sheetUser && sheetUser.getLastRow() > 1) {
          const userRows = sheetUser.getDataRange().getValues();
          const recipientRow = findUserRow(userRows, data.to);
          if (recipientRow && recipientRow[11]) {
            recipientLineId = recipientRow[11].toString().trim();
          }
        }

        if (recipientLineId) {
          const attachmentNotice = attachmentUrls.length > 0 ? `\n（画像${attachmentUrls.length}枚が添付されています）` : "";
          const lineNoticeText = `💬【平工マッチング】新着メッセージ\n\n${senderName} さんからメッセージが届きました：\n「${data.text || "画像が送信されました"}」${attachmentNotice}`;
          sendLineNotification(recipientLineId, lineNoticeText);
        }

        return createRes("success", "SENT");

      } catch (e) {
        return createRes("error", "書き込み混雑中です。再度お試しください。");
      } finally {
        lock.releaseLock();
      }
    }

    if (mode === "getMessages") {
      if (!sheetChat || sheetChat.getLastRow() <= 1) return createRes("success", []);
      const rows = getChatRows(sheetChat);
      const hiddenAt = getChatHiddenAt(sheetHiddenChat, data.user1, data.user2);
      let msgs = [];
      for (let i = 1; i < rows.length; i++) {
        const isPair = (rows[i][0] === data.user1 && rows[i][1] === data.user2) ||
          (rows[i][0] === data.user2 && rows[i][1] === data.user1);
        const sentAt = new Date(rows[i][3]).getTime();
        const isAfterHidden = !hiddenAt || Number.isNaN(sentAt) || sentAt > hiddenAt;

        if (isPair && isAfterHidden) {
          let attachments = [];
          try {
            const parsedAttachments = rows[i][7] ? JSON.parse(rows[i][7]) : [];
            if (Array.isArray(parsedAttachments)) attachments = parsedAttachments;
          } catch (e) {
            attachments = [];
          }

          msgs.push({
            messageId: rows[i][5] || `legacy-${i + 1}`,
            from: rows[i][0],
            text: rows[i][2],
            sentAt: rows[i][3],
            isRead: rows[i][4] === "read",
            isUnsent: rows[i][6] === "unsent",
            attachments
          });
        }
      }
      return createRes("success", msgs);
    }

    if (mode === "unsendMessage") {
      if (!sheetChat) return createRes("error", "チャットシートが存在しません");

      ensureChatColumns(sheetChat);

      const userId = String(data.userId || "").trim();
      const messageId = String(data.messageId || "").trim();
      if (!userId || !messageId) return createRes("error", "送信取り消しに必要な情報が不足しています");

      const rows = getChatRows(sheetChat);
      let targetRowIndex = -1;

      for (let i = 1; i < rows.length; i++) {
        const rowMessageId = rows[i][5] || `legacy-${i + 1}`;
        if (rowMessageId === messageId && rows[i][0] === userId) {
          targetRowIndex = i + 1;
          break;
        }
      }

      if (targetRowIndex === -1) return createRes("error", "取り消せるメッセージが見つかりません");

      sheetChat.getRange(targetRowIndex, 3).setValue("このメッセージは送信取り消しされました。");
      if (!sheetChat.getRange(targetRowIndex, 6).getValue()) {
        sheetChat.getRange(targetRowIndex, 6).setValue(messageId);
      }
      sheetChat.getRange(targetRowIndex, 7).setValue("unsent");
      sheetChat.getRange(targetRowIndex, 8).setValue("[]");
      return createRes("success", "MESSAGE_UNSENT");
    }

    if (mode === "deleteChatHistory") {
      const userId = String(data.userId || "").trim();
      const targetUserId = String(data.targetUserId || "").trim();
      if (!userId || !targetUserId || userId === targetUserId) {
        return createRes("error", "削除対象のチャットが正しくありません");
      }

      const hiddenChatSheet = sheetHiddenChat || getOrCreateSheet(ss, "チャット非表示", ["UserID", "相手UserID", "非表示日時"]);
      const rows = hiddenChatSheet.getLastRow() > 1 ? hiddenChatSheet.getDataRange().getValues() : [];
      const now = new Date();
      let foundRowIndex = -1;

      for (let i = 1; i < rows.length; i++) {
        if (rows[i][0] === userId && rows[i][1] === targetUserId) {
          foundRowIndex = i + 1;
          break;
        }
      }

      if (foundRowIndex === -1) {
        hiddenChatSheet.appendRow([userId, targetUserId, now]);
      } else {
        hiddenChatSheet.getRange(foundRowIndex, 3).setValue(now);
      }

      return createRes("success", "CHAT_HISTORY_HIDDEN");
    }

    if (mode === "getChatPartners") {
      if (!sheetChat || sheetChat.getLastRow() <= 1) return createRes("success", []);
      const rows = getChatRows(sheetChat);
      const myEmail = data.email;
      let partnersSet = new Set();
      const hiddenAtByPartner = {};
      if (sheetHiddenChat && sheetHiddenChat.getLastRow() > 1) {
        const hiddenRows = sheetHiddenChat.getDataRange().getValues();
        for (let i = 1; i < hiddenRows.length; i++) {
          if (hiddenRows[i][0] !== myEmail) continue;
          const partner = hiddenRows[i][1];
          const hiddenAt = new Date(hiddenRows[i][2]).getTime();
          if (!Number.isNaN(hiddenAt) && hiddenAt > (hiddenAtByPartner[partner] || 0)) {
            hiddenAtByPartner[partner] = hiddenAt;
          }
        }
      }

      for (let i = 1; i < rows.length; i++) {
        const fromUser = rows[i][0];
        const toUser = rows[i][1];
        const sentAt = new Date(rows[i][3]).getTime();
        const partner = fromUser === myEmail ? toUser : fromUser;
        const hiddenAt = hiddenAtByPartner[partner] || 0;
        const isAfterHidden = !hiddenAt || Number.isNaN(sentAt) || sentAt > hiddenAt;

        if (!isAfterHidden || rows[i][6] === "unsent") continue;

        if (fromUser === myEmail) {
          partnersSet.add(toUser);
        } else if (toUser === myEmail) {
          partnersSet.add(fromUser);
        }
      }

      const partnerEmails = Array.from(partnersSet);
      let partnerList = [];

      const userRows = (sheetUser && sheetUser.getLastRow() > 0) ? sheetUser.getDataRange().getValues() : [];
      partnerEmails.forEach(pEmail => {
        if (isBlockedBetween(sheetBlock, myEmail, pEmail)) return;
        const userRow = findUserRow(userRows, pEmail);
        const pName = getUserDisplayName(userRow, pEmail || "未設定");
        partnerList.push({ email: pEmail, name: pName });
      });

      return createRes("success", partnerList);
    }

    if (mode === "blockUser") {
      const blockerId = String(data.blockerId || "").trim();
      const blockedId = String(data.blockedId || "").trim();
      if (!blockerId || !blockedId || blockerId === blockedId) {
        return createRes("error", "ブロック対象が正しくありません");
      }
      if (!userExists(sheetUser, blockedId)) {
        return createRes("error", "対象ユーザーが見つかりません");
      }

      const blockSheet = sheetBlock || getOrCreateSheet(ss, "ブロック", [
        "ブロックしたUserID", "ブロックされたUserID", "ブロック日時", "状態"
      ]);
      const rows = blockSheet.getLastRow() > 1 ? blockSheet.getDataRange().getValues() : [];
      for (let i = 1; i < rows.length; i++) {
        if (rows[i][0] === blockerId && rows[i][1] === blockedId && rows[i][3] !== "解除") {
          return createRes("success", "ALREADY_BLOCKED");
        }
      }

      blockSheet.appendRow([blockerId, blockedId, new Date(), "有効"]);
      return createRes("success", "BLOCKED");
    }

    if (mode === "unblockUser") {
      const blockerId = String(data.blockerId || "").trim();
      const blockedId = String(data.blockedId || "").trim();
      if (!sheetBlock || sheetBlock.getLastRow() <= 1) return createRes("success", "UNBLOCKED");
      const rows = sheetBlock.getDataRange().getValues();
      for (let i = rows.length - 1; i >= 1; i--) {
        if (rows[i][0] === blockerId && rows[i][1] === blockedId && rows[i][3] !== "解除") {
          sheetBlock.getRange(i + 1, 4).setValue("解除");
        }
      }
      return createRes("success", "UNBLOCKED");
    }

    if (mode === "getBlockedUsers") {
      const blockerId = String(data.blockerId || "").trim();
      const rows = sheetBlock && sheetBlock.getLastRow() > 1 ? sheetBlock.getDataRange().getValues() : [];
      const userRows = sheetUser && sheetUser.getLastRow() > 1 ? sheetUser.getDataRange().getValues() : [];
      const blockedIds = [];

      for (let i = 1; i < rows.length; i++) {
        if (rows[i][0] === blockerId && rows[i][3] !== "解除") {
          const blockedId = rows[i][1];
          const userRow = userRows.find(row => row[0] === blockedId || row[5] === blockedId);
          blockedIds.push({
            userId: blockedId,
            name: userRow ? (userRow[2] || "未設定") : "未設定"
          });
        }
      }

      return createRes("success", blockedIds);
    }

    if (mode === "reportContent") {
      const reporterId = String(data.reporterId || "").trim();
      const targetUserId = String(data.targetUserId || "").trim();
      const targetType = String(data.targetType || "").trim();
      const targetId = String(data.targetId || "").trim();
      const reason = String(data.reason || "").trim();

      if (!reporterId || !targetUserId || !targetType || !reason) {
        return createRes("error", "通報に必要な情報が不足しています");
      }
      if (!userExists(sheetUser, targetUserId)) {
        return createRes("error", "通報対象のユーザーが見つかりません");
      }

      const reportSheet = sheetReport || getOrCreateSheet(ss, "通報", [
        "通報ID", "通報者UserID", "対象UserID", "対象種類", "対象ID",
        "対象内容", "通報理由", "詳細", "通報日時", "対応状況", "管理者メモ"
      ]);
      const reportId = Utilities.getUuid();
      reportSheet.appendRow([
        reportId,
        reporterId,
        targetUserId,
        targetType,
        targetId,
        String(data.targetContent || ""),
        reason,
        String(data.detail || ""),
        new Date(),
        "未対応",
        ""
      ]);
      return createRes("success", "REPORTED");
    }

    if (mode === "getReports") {
      if (data.adminId !== ADMIN_USER_ID) return createRes("error", "管理者権限がありません");
      const rows = sheetReport && sheetReport.getLastRow() > 1 ? sheetReport.getDataRange().getValues() : [];
      const reports = [];
      for (let i = 1; i < rows.length; i++) {
        reports.push({
          reportId: rows[i][0], reporterId: rows[i][1], targetUserId: rows[i][2],
          targetType: rows[i][3], targetId: rows[i][4], targetContent: rows[i][5],
          reason: rows[i][6], detail: rows[i][7], reportedAt: rows[i][8],
          status: rows[i][9] || "未対応", adminMemo: rows[i][10] || ""
        });
      }
      return createRes("success", reports);
    }

    if (mode === "updateReportStatus") {
      if (data.adminId !== ADMIN_USER_ID) return createRes("error", "管理者権限がありません");
      if (!sheetReport || sheetReport.getLastRow() <= 1) return createRes("error", "通報が見つかりません");
      const reportId = String(data.reportId || "").trim();
      const nextStatus = String(data.status || "未対応").trim();
      const rows = sheetReport.getDataRange().getValues();
      for (let i = 1; i < rows.length; i++) {
        if (rows[i][0] === reportId) {
          sheetReport.getRange(i + 1, 10).setValue(nextStatus);
          if (data.adminMemo !== undefined) sheetReport.getRange(i + 1, 11).setValue(data.adminMemo);
          return createRes("success", "REPORT_UPDATED");
        }
      }
      return createRes("error", "通報が見つかりません");
    }

    if (mode === "getLatestIncomingMessage") {
      if (!sheetChat || sheetChat.getLastRow() <= 1) return createRes("success", null);
      const rows = getChatRows(sheetChat);
      const myEmail = data.email;

      for (let i = rows.length - 1; i >= 1; i--) {
        if (rows[i] && rows[i][1] === myEmail && rows[i][6] !== "unsent") {
          const senderEmail = rows[i][0] || "";
          const text = rows[i][2] || "";
          const rawDate = rows[i][3];
          const time = rawDate ? new Date(rawDate).getTime() : 0;

          const userRows = (sheetUser && sheetUser.getLastRow() > 0) ? sheetUser.getDataRange().getValues() : [];
          const userRow = findUserRow(userRows, senderEmail);
          const senderName = getUserDisplayName(userRow, senderEmail || "ユーザー");

          return createRes("success", {
            fromEmail: senderEmail,
            fromName: senderName,
            text: text,
            time: time
          });
        }
      }
      return createRes("success", null);
    }

    if (mode === "getUnreadCount") {
      if (!sheetChat || sheetChat.getLastRow() <= 1) return createRes("success", { unreadCount: 0 });
      const rows = getChatRows(sheetChat);
      const myEmail = data.email;
      let unreadCount = 0;

      for (let i = 1; i < rows.length; i++) {
        if (rows[i] && rows[i][1] === myEmail && rows[i][4] === "unread" && rows[i][6] !== "unsent") {
          unreadCount++;
        }
      }
      return createRes("success", { unreadCount: unreadCount });
    }

    if (mode === "getNotificationSummary") {
      if (!sheetChat || sheetChat.getLastRow() <= 1) {
        return createRes("success", { unreadCount: 0, latestIncoming: null });
      }

      const rows = getChatRows(sheetChat);
      const myEmail = data.email;
      let unreadCount = 0;
      let latestIncoming = null;
      const userRows = (sheetUser && sheetUser.getLastRow() > 0) ? sheetUser.getDataRange().getValues() : [];

      for (let i = 1; i < rows.length; i++) {
        const row = rows[i];
        if (!row || row[6] === "unsent") continue;

        if (row[1] === myEmail && row[4] === "unread") unreadCount++;

        if (row[1] === myEmail) {
          const time = row[3] ? new Date(row[3]).getTime() : 0;
          if (!latestIncoming || time >= latestIncoming.time) {
            const senderId = row[0] || "";
            const userRow = findUserRow(userRows, senderId);
            latestIncoming = {
              fromEmail: senderId,
              fromName: getUserDisplayName(userRow, senderId || "ユーザー"),
              text: row[2] || "",
              time: time
            };
          }
        }
      }

      return createRes("success", {
        unreadCount: unreadCount,
        latestIncoming: latestIncoming
      });
    }

    if (mode === "markAsRead") {
      if (!sheetChat || sheetChat.getLastRow() <= 1) return createRes("success", "READ_MARKED");
      const rows = getChatRows(sheetChat);
      const myEmail = data.myEmail;
      const targetEmail = data.targetEmail;

      for (let i = 1; i < rows.length; i++) {
        if (rows[i] && rows[i][0] === targetEmail && rows[i][1] === myEmail && rows[i][4] === "unread") {
          sheetChat.getRange(i + 1, 5).setValue("read");
        }
      }
      return createRes("success", "READ_MARKED");
    }

    if (mode === "deleteAccount") {
      const email = data.email;
      if (!sheetUser || sheetUser.getLastRow() <= 1) return createRes("error", "ユーザーが見つかりません");

      const rows = sheetUser.getDataRange().getValues();
      let userDeleted = false;

      for (let i = rows.length - 1; i >= 1; i--) {
        if (rows[i][0] === email || rows[i][5] === email) {
          sheetUser.deleteRow(i + 1);
          userDeleted = true;
          break;
        }
      }

      if (sheetRecruit && sheetRecruit.getLastRow() > 1) {
        const recruitRows = sheetRecruit.getDataRange().getValues();
        for (let j = recruitRows.length - 1; j >= 1; j--) {
          if (recruitRows[j][5] === email) {
            sheetRecruit.deleteRow(j + 1);
          }
        }
      }

      if (userDeleted) {
        return createRes("success", "ACCOUNT_DELETED");
      } else {
        return createRes("error", "対象ユーザーが見つかりませんでした");
      }
    }

    if (mode === "forgotPassword") {
      const userId = data.userId;
      if (!sheetUser || sheetUser.getLastRow() === 0) return createRes("error", "ユーザーが見つかりません");
      const rows = sheetUser.getDataRange().getValues();

      let userRowIndex = -1;
      for (let i = 0; i < rows.length; i++) {
        if (rows[i][0] === userId) {
          userRowIndex = i + 1;
          break;
        }
      }
      if (userRowIndex === -1) return createRes("success", "MAIL_SENT_IF_EXISTS");

      const row = rows[userRowIndex - 1];
      const email = row[5];
      if (!email) return createRes("success", "MAIL_SENT_IF_EXISTS");

      const token = generateResetToken();
      const expiry = new Date().getTime() + (30 * 60 * 1000);

      sheetUser.getRange(userRowIndex, 10).setValue(token);
      sheetUser.getRange(userRowIndex, 11).setValue(expiry);

      const resetLink = `${SITE_URL}reset.html?id=${encodeURIComponent(userId)}&token=${token}`;

      MailApp.sendEmail({
        to: email,
        name: "平工マッチング",
        subject: "【平工マッチング】認証コードのご案内",
        body: `パスワード再設定のリクエストを受け付けました。\n\n30分以内に、以下のリンクから新しいパスワードを設定してください。\n\n${resetLink}`
      });

      return createRes("success", "MAIL_SENT_IF_EXISTS");
    }

    if (mode === "resetPassword") {
      const userId = data.userId;
      const token = data.token;
      const newPassword = data.newPassword;

      if (!sheetUser || sheetUser.getLastRow() === 0) return createRes("error", "無効なリンクです。");
      const rows = sheetUser.getDataRange().getValues();

      let userRowIndex = -1;
      for (let i = 1; i < rows.length; i++) {
        if (rows[i][0] === userId) {
          userRowIndex = i + 1;
          break;
        }
      }
      if (userRowIndex === -1) return createRes("error", "無効なリンクです");

      const savedToken = rows[userRowIndex - 1][9];
      const savedExpiry = rows[userRowIndex - 1][10];

      if (!savedToken || savedToken !== token) return createRes("error", "リンクが無効です。");
      if (!savedExpiry || new Date().getTime() > savedExpiry) return createRes("error", "リンクの有効期限が切れています。");
      if (!newPassword || newPassword.length < 4) return createRes("error", "パスワードは4文字以上で設定してください。");

      sheetUser.getRange(userRowIndex, 2).setValue(hashPassword(newPassword));
      sheetUser.getRange(userRowIndex, 10).setValue("");
      sheetUser.getRange(userRowIndex, 11).setValue("");

      return createRes("success", "PASSWORD_RESET");
    }

    return createRes("error", "未対応のモードです: " + mode);

  } catch (err) {
    return createRes("error", err.toString());
  }
}

function getFaceDistance(currentLandmarks, registeredLandmarks) {
  if (!Array.isArray(currentLandmarks) || !Array.isArray(registeredLandmarks)) return null;
  const pointCount = Math.min(currentLandmarks.length, registeredLandmarks.length);
  if (pointCount < 400 || Math.abs(currentLandmarks.length - registeredLandmarks.length) > 10) return null;

  const current = normalizeFaceLandmarks(currentLandmarks);
  const registered = normalizeFaceLandmarks(registeredLandmarks);
  if (!current || !registered) return null;

  const distances = [];
  for (let i = 0; i < pointCount; i++) {
    const dx = current[i].x - registered[i].x;
    const dy = current[i].y - registered[i].y;
    const dz = (current[i].z - registered[i].z) * 0.5;
    distances.push(Math.sqrt(dx * dx + dy * dy + dz * dz));
  }

  distances.sort((a, b) => a - b);
  const trim = Math.floor(distances.length * 0.1);
  let totalDistance = 0;
  let usedPoints = 0;
  for (let i = trim; i < distances.length - trim; i++) {
    totalDistance += distances[i];
    usedPoints++;
  }

  return usedPoints ? totalDistance / usedPoints : null;
}

function normalizeFaceLandmarks(landmarks) {
  const leftEye = landmarks[33];
  const rightEye = landmarks[263];
  if (!leftEye || !rightEye) return null;

  const values = [leftEye.x, leftEye.y, rightEye.x, rightEye.y];
  if (values.some(value => typeof value !== "number" || !isFinite(value))) return null;

  const centerX = (leftEye.x + rightEye.x) / 2;
  const centerY = (leftEye.y + rightEye.y) / 2;
  const centerZ = ((leftEye.z || 0) + (rightEye.z || 0)) / 2;
  const eyeX = rightEye.x - leftEye.x;
  const eyeY = rightEye.y - leftEye.y;
  const scale = Math.sqrt(eyeX * eyeX + eyeY * eyeY);
  if (!scale || !isFinite(scale)) return null;

  const angle = Math.atan2(eyeY, eyeX);
  const cos = Math.cos(-angle);
  const sin = Math.sin(-angle);
  const normalized = [];

  for (let i = 0; i < landmarks.length; i++) {
    const point = landmarks[i];
    if (!point || typeof point.x !== "number" || typeof point.y !== "number" || !isFinite(point.x) || !isFinite(point.y)) return null;

    const x = (point.x - centerX) / scale;
    const y = (point.y - centerY) / scale;
    const z = ((point.z || 0) - centerZ) / scale;
    normalized.push({
      x: x * cos - y * sin,
      y: x * sin + y * cos,
      z: z
    });
  }

  return normalized;
}

function createRes(status, msg) {
  return ContentService.createTextOutput(JSON.stringify({ status: status, message: msg }))
    .setMimeType(ContentService.MimeType.JSON);
}

function cleanCell(value) {
  if (value === null || value === undefined) return "";
  const text = String(value).trim();
  return text === "undefined" || text === "null" ? "" : text;
}

function findUserRow(rows, identifier) {
  const key = cleanCell(identifier);
  if (!key) return null;
  return rows.find(row => cleanCell(row[0]) === key || cleanCell(row[5]) === key) || null;
}

function getUserDisplayName(userRow, fallback) {
  const name = userRow ? cleanCell(userRow[2]) : "";
  return name || cleanCell(fallback) || "ユーザー";
}

function getOrCreateSheet(ss, name, headers) {
  let sheet = ss.getSheetByName(name);
  if (!sheet) sheet = ss.insertSheet(name);
  if (sheet.getLastRow() === 0) sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
  return sheet;
}

function ensureRecruitmentDurationColumn(sheetRecruit) {
  if (sheetRecruit.getLastRow() === 0) {
    sheetRecruit.getRange(1, 1, 1, 8).setValues([["名前", "学年", "学科", "勉強内容", "投稿時刻", "UserID", "tags", "表示時間（分）"]]);
    return;
  }

  if (!sheetRecruit.getRange(1, 8).getValue()) {
    sheetRecruit.getRange(1, 8).setValue("表示時間（分）");
  }
}

function ensureChatColumns(sheetChat) {
  if (sheetChat.getLastRow() === 0) {
    sheetChat.getRange(1, 1, 1, 8).setValues([["送信元", "送信先", "内容", "日時", "既読", "メッセージID", "状態", "添付JSON"]]);
    return;
  }

  if (!sheetChat.getRange(1, 6).getValue()) sheetChat.getRange(1, 6).setValue("メッセージID");
  if (!sheetChat.getRange(1, 7).getValue()) sheetChat.getRange(1, 7).setValue("状態");
  if (!sheetChat.getRange(1, 8).getValue()) sheetChat.getRange(1, 8).setValue("添付JSON");
}

function getChatRows(sheetChat) {
  const lastRow = sheetChat.getLastRow();
  return lastRow > 0 ? sheetChat.getRange(1, 1, lastRow, 8).getValues() : [];
}

function getChatImageFolder() {
  const properties = PropertiesService.getScriptProperties();
  const savedFolderId = properties.getProperty("CHAT_IMAGE_FOLDER_ID");

  if (savedFolderId) {
    try {
      return DriveApp.getFolderById(savedFolderId);
    } catch (e) {
      properties.deleteProperty("CHAT_IMAGE_FOLDER_ID");
    }
  }

  const folder = DriveApp.createFolder("平工マッチング_チャット画像");
  properties.setProperty("CHAT_IMAGE_FOLDER_ID", folder.getId());
  return folder;
}

function saveChatAttachments(attachments, senderId) {
  if (!Array.isArray(attachments) || attachments.length === 0) return [];

  const folder = getChatImageFolder();
  const savedUrls = [];

  attachments.slice(0, 8).forEach((attachment, index) => {
    try {
      const dataUrl = String(attachment && attachment.data || "");
      const commaIndex = dataUrl.indexOf(",");
      if (commaIndex < 0) return;

      const metadata = dataUrl.slice(0, commaIndex);
      const base64 = dataUrl.slice(commaIndex + 1);
      const mimeMatch = metadata.match(/^data:(image\/[a-zA-Z0-9.+-]+);base64$/);
      const mimeType = mimeMatch ? mimeMatch[1].toLowerCase() : "image/jpeg";
      if (!mimeType.startsWith("image/")) return;

      const bytes = Utilities.base64Decode(base64);
      if (bytes.length > 450 * 1024) return;

      const originalName = cleanCell(attachment && attachment.name) || `image-${index + 1}.jpg`;
      const safeName = originalName.replace(/[^\w.\-ぁ-んァ-ヶ一-龠]/g, "_").slice(0, 80);
      const fileName = `${Date.now()}_${cleanCell(senderId) || "user"}_${safeName}`;
      const file = folder.createFile(Utilities.newBlob(bytes, mimeType, fileName));
      file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
      savedUrls.push(`https://drive.google.com/uc?export=view&id=${file.getId()}`);
    } catch (e) {
      console.log(`チャット画像保存失敗: ${e}`);
    }
  });

  return savedUrls;
}

function sameChatPair(firstUser, secondUser, user1, user2) {
  return (firstUser === user1 && secondUser === user2) ||
    (firstUser === user2 && secondUser === user1);
}

function getChatHiddenAt(sheetHiddenChat, user1, user2) {
  if (!sheetHiddenChat || sheetHiddenChat.getLastRow() <= 1) return 0;

  const rows = sheetHiddenChat.getDataRange().getValues();
  let hiddenAt = 0;

  for (let i = 1; i < rows.length; i++) {
    if (rows[i][0] !== user1 || rows[i][1] !== user2) continue;
    const currentHiddenAt = new Date(rows[i][2]).getTime();
    if (!Number.isNaN(currentHiddenAt) && currentHiddenAt > hiddenAt) {
      hiddenAt = currentHiddenAt;
    }
  }

  return hiddenAt;
}

function normalizeRecruitmentDuration(value) {
  const minutes = Number(value);
  return RECRUITMENT_DURATION_MINUTES.includes(minutes) ? minutes : 1440;
}

function touchOnlineUser(sheetOnline, userId) {
  const lock = LockService.getScriptLock();

  try {
    lock.waitLock(3000);
    const rows = sheetOnline.getLastRow() > 1 ? sheetOnline.getDataRange().getValues() : [];
    let rowIndex = -1;

    for (let i = 1; i < rows.length; i++) {
      if (String(rows[i][0] || "") === userId) {
        rowIndex = i + 1;
        break;
      }
    }

    if (rowIndex === -1) {
      sheetOnline.appendRow([userId, new Date()]);
    } else {
      sheetOnline.getRange(rowIndex, 2).setValue(new Date());
    }
  } finally {
    if (lock.hasLock()) lock.releaseLock();
  }
}

function getOnlineUserIds(sheetOnline) {
  if (!sheetOnline || sheetOnline.getLastRow() <= 1) return [];

  const cutoff = Date.now() - ONLINE_TIMEOUT_MS;
  const rows = sheetOnline.getDataRange().getValues();
  const userIds = [];
  const seen = {};

  for (let i = 1; i < rows.length; i++) {
    const userId = String(rows[i][0] || "").trim();
    const lastSeen = new Date(rows[i][1]).getTime();

    if (userId && !Number.isNaN(lastSeen) && lastSeen >= cutoff && !seen[userId]) {
      seen[userId] = true;
      userIds.push(userId);
    }
  }

  return userIds;
}

function userExists(sheetUser, userId) {
  if (!sheetUser || sheetUser.getLastRow() <= 1) return false;
  const rows = sheetUser.getDataRange().getValues();
  return rows.slice(1).some(row => row[0] === userId || row[5] === userId);
}

function isBlockedBetween(sheetBlock, userA, userB) {
  if (!sheetBlock || !userA || !userB || sheetBlock.getLastRow() <= 1) return false;
  const rows = sheetBlock.getDataRange().getValues();
  return rows.slice(1).some(row => {
    if (row[3] === "解除") return false;
    return (row[0] === userA && row[1] === userB) || (row[0] === userB && row[1] === userA);
  });
}

function hashPassword(password) {
  const rawHash = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, password, Utilities.Charset.UTF_8);
  return rawHash.map(byte => {
    const v = (byte < 0 ? byte + 256 : byte).toString(16);
    return v.length === 1 ? "0" + v : v;
  }).join("");
}

function generateResetToken() { return Utilities.getUuid(); }
function generateVerificationCode() { return Math.floor(100000 + Math.random() * 900000).toString(); }

function sendLineNotification(toUserId, messageText) {
  if (!LINE_ACCESS_TOKEN || LINE_ACCESS_TOKEN.includes("ここに")) return;

  const url = "https://api.line.me/v2/bot/message/push";

  const payload = {
    to: toUserId,
    messages: [
      {
        type: "text",
        text: messageText
      }
    ]
  };

  const options = {
    method: "post",
    headers: {
      "Content-Type": "application/json",
      "Authorization": "Bearer " + LINE_ACCESS_TOKEN
    },
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  };

  try {
    UrlFetchApp.fetch(url, options);
  } catch (e) {
    console.error("LINE通知エラー:", e);
  }
}

function replyLineMessage(replyToken, messageText) {
  if (!LINE_ACCESS_TOKEN || !replyToken) {
    console.log("エラー: アクセストークンまたはreplyTokenがありません");
    return;
  }

  const url = "https://api.line.me/v2/bot/message/reply";

  const payload = {
    replyToken: replyToken,
    messages: [
      {
        type: "text",
        text: messageText
      }
    ]
  };

  const options = {
    method: "post",
    headers: {
      "Content-Type": "application/json",
      "Authorization": "Bearer " + LINE_ACCESS_TOKEN
    },
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  };

  try {
    const response = UrlFetchApp.fetch(url, options);
    console.log("LINE APIレスポンスコード: " + response.getResponseCode());
    console.log("LINE APIレスポンス内容: " + response.getContentText());
  } catch (e) {
    console.error("LINE返信エラー:", e);
  }
}

function testManualPush() {
  const lineUserId = "Ua0dfab5109824398a28f2c5ae2e479d8";
  const msg = "🔔 テストプッシュ通知です！";
  sendLineNotification(lineUserId, msg);
  console.log("テスト送信を実行しました。");
}
